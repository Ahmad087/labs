<script>
	function myFunction() {
    document.getElementById("theString").style.color = "blue";
	}
	</script>